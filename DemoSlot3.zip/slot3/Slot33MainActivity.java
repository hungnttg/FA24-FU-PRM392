package com.hnq40.myapplication10.slot3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.hnq40.myapplication10.R;

public class Slot33MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot33_main);
    }
}