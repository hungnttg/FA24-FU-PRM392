package com.hnq40.myapplication10.slot3

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import com.hnq40.myapplication10.R

class Slot34MainActivity : AppCompatActivity() {
    //declare variable
    var listView: ListView? = null

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_slot34_main)
        //reference
        listView = findViewById(R.id.slot34Lv)
        dataToListview
    }

    private val dataToListview: Unit
        private get() {
            //1. create data source
            val arr = arrayOf(
                "lap trinh java",
                "Computer science introduction",
                "Mobile programing",
                "Cross-platform",

                )
            //2.Using adapter
            val adapter = ArrayAdapter(
                this@Slot34MainActivity,
                android.R.layout.simple_list_item_1, arr
            )
            //3. attach adapter to Listview
            listView!!.adapter = adapter
        }
}