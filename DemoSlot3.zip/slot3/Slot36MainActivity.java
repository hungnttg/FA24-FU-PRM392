package com.hnq40.myapplication10.slot3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.hnq40.myapplication10.R;

public class Slot36MainActivity extends AppCompatActivity {
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot34_main);
        listView=findViewById(R.id.slot34Lv);
        getDataToListview();
    }

    private void getDataToListview() {
        String[] arr=new String[]{
                "lap trinh java",
                "Computer science introduction",
                "mobile programming",
                "cross platform",
                "java form"
        };
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1,arr);
        listView.setAdapter(adapter);
    }
}