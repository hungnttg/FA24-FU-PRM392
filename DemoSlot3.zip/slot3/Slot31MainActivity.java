package com.hnq40.myapplication10.slot3;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.hnq40.myapplication10.R;

public class Slot31MainActivity extends AppCompatActivity {
    EditText txtA,txtB,txtC;
    Button btn1;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot31_main);
        txtA=findViewById(R.id.slot31TxtA);
        txtB=findViewById(R.id.slot31TxtB);
        txtC=findViewById(R.id.slot31TxtC);
        btn1=findViewById(R.id.slot31Btn1);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendData();
            }
        });
    }

    private void sendData() {
        //get data from input of user
        String a=txtA.getText().toString();
        String b=txtB.getText().toString();
        String c=txtC.getText().toString();
        //create intent
        Intent intent=new Intent(Slot31MainActivity.this,Slot32MainActivity.class);
        //put data to intent
        intent.putExtra("hsa",a);
        intent.putExtra("hsb",b);
        intent.putExtra("hsc",c);
        //start activity
        startActivity(intent);
    }
}