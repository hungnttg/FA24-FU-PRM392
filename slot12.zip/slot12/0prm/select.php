<?php
//tao header full control
header('Access-Control-Allow-Origin: *');
//khai bao thong tin server
$host="localhost";$u="root";$p="";$db="a6";
//ket noi voi db
$conn=new mysqli($host,$u,$p,$db);
//truy van
$result=$conn->query("select * from mytable");
//doc ket qua
while($row[]=$result->fetch_assoc()){
    $json=json_encode($row);//chuyen ket qua sang json
}
//in ket qua
echo '{"products":'.$json.'}';
//dong ket noi 
$conn->close();