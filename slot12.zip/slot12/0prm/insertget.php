<?php
$response = array();
$host="localhost";$u="root";$p="";$db="a6";//khai bao thong tin csdl
$conn=new mysqli($host,$u,$p,$db);//tao ket noi
//truyen tham so
//http://localhost/0prm/insert.php?id=123&name=an&price=123&description=abcd
if(isset($_GET['id']) && isset($_GET['name']) && isset($_GET['price'])&& isset($_GET['description'])){
    //lay gia tri cua cac tham so
    $id=$_GET['id'];
    $name=$_GET['name'];
    $price=$_GET['price'];
    $description=$_GET['description'];
    $sql="insert into products values ('$id','$name','$price','$description')";
    if($conn->query($sql)===TRUE){
        $response['success']=1;
        $response['message']="Insert thanh cong";
        echo json_encode($response);
    }
    else {
        $response['success']=1;
        $response['message']=$conn->error;
        echo json_encode($response);
    }
}
$conn->close();
