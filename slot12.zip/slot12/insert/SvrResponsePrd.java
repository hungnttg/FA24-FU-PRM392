package com.hnq40.myapplication10.slot12.insert;

public class SvrResponsePrd {//GET
    private Prd products;
    private String message;

    public Prd getProducts() {
        return products;
    }

    public String getMessage() {
        return message;
    }
}
