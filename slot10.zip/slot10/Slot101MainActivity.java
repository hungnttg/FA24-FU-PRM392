package com.hnq40.myapplication10.slot10;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ListView;

import com.hnq40.myapplication10.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class Slot101MainActivity extends AppCompatActivity {
    ListView listView;
    private AdapterSL10 adapter;
    private List<ProductSL10> list=new ArrayList<>();
    private Context context=this;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot101_main);
        listView=findViewById(R.id.slot10Lv);
        adapter=new AdapterSL10(this,list);
        listView.setAdapter(adapter);
        //lay du lieu tu server
        new FetchPrdSL10().execute();
    }
    private class FetchPrdSL10 extends AsyncTask<Void,Void,String>{
        //doc du lieu tu server
        @Override
        protected String doInBackground(Void... voids) {
            StringBuilder response=new StringBuilder();//chua ket qua
            try {
                URL url=new URL("http://10.22.10.72/0prm/api.php");
                //mo ket noi
                HttpURLConnection connection=(HttpURLConnection) url.openConnection();
                //phuong thuc doc du lieu
                connection.setRequestMethod("GET");
                //dung buffereader doc du lieu
                BufferedReader reader=new BufferedReader(new InputStreamReader(connection.getInputStream()));
                //khai bao dong chua du lieu
                String line="";
                while ((line=reader.readLine())!=null){//doc theo dong
                    response.append(line);//dua tung dong vao ket qua
                }
            } catch (MalformedURLException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            return response.toString();//tra ve ket qua
        }
        //tra ve ket qua cho client
        @Override
        protected void onPostExecute(String result) {
            if(result!=null && !result.isEmpty()){
                try {
                    JSONObject jsonObject=new JSONObject(result);//tra ve doi tuong result
                    JSONArray prdArray=jsonObject.getJSONArray("products");//tra ve mang product
                    for(int i=0;i<prdArray.length();i++){
                        JSONObject p=prdArray.getJSONObject(i);//lay ve doi tuong con (dong)
                        String styleId=p.getString("styleid");//lay du lieu truong styleID
                        String info=p.getString("product_additional_info");
                        String search_image=p.getString("search_image");
                        //dua cac truong du lieu vao doi tuong
                        ProductSL10 productSL10=new ProductSL10();
                        productSL10.setStyleid(styleId);
                        productSL10.setProduct_additional_info(info);
                        productSL10.setSearch_image(search_image);
                        //dua doi tuong vao list
                        list.add(productSL10);
                    }
                    //lam moi
                    adapter.notifyDataSetChanged();
                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
}