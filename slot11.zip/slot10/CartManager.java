package com.hnq40.myapplication10.slot10;

import java.util.ArrayList;
import java.util.List;

public class CartManager {
    private static CartManager instance;
    private List<ProductSL10> cartItems;

    private CartManager() {
        cartItems=new ArrayList<>();
    }
    public static synchronized CartManager getInstance(){
        if(instance==null){
            instance=new CartManager();
        }
        return instance;
    }
    public void addProductToCart(ProductSL10 p){
        cartItems.add(p);
    }
    public List<ProductSL10> getCartItems(){
        return cartItems;
    }
}
