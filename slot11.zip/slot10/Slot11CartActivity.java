package com.hnq40.myapplication10.slot10;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ListView;

import com.hnq40.myapplication10.R;

import java.util.List;

public class Slot11CartActivity extends AppCompatActivity {
    private ListView lv;
    private CartAdapterSL11 cartAdapter;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot11_cart);
        lv=findViewById(R.id.slot11_cart_activity_listview);
        //khoi tao danh sach gio hang
        CartManager cartManager=CartManager.getInstance();
        List<ProductSL10> cartItems=cartManager.getCartItems();
        //khoi tao adapter
        cartAdapter=new CartAdapterSL11(this,cartItems);
        lv.setAdapter(cartAdapter);
    }
}