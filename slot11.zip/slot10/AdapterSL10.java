package com.hnq40.myapplication10.slot10;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.hnq40.myapplication10.R;
import com.squareup.picasso.Picasso;

import java.util.List;

public class AdapterSL10 extends BaseAdapter {
    private Context mContext;
    private List<ProductSL10> list;

    public AdapterSL10(Context mContext, List<ProductSL10> list) {
        this.mContext = mContext;
        this.list = list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
    //tao view
    //gan du lieu
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //tao view
        ViewHolderSL10 holder;
        if(convertView==null){
            convertView= LayoutInflater.from(mContext)
                    .inflate(R.layout.slot41_item_view,parent,false);
            holder=new ViewHolderSL10();
            holder.imageView=convertView.findViewById(R.id.slot41_item_hinh);
            holder.styleidTv=convertView.findViewById(R.id.slot41_item_ten);
            holder.addInfoTv=convertView.findViewById(R.id.slot41_item_tuoi);
            convertView.setTag(holder);
        }
        else {
            holder=(ViewHolderSL10) convertView.getTag();
        }
        //gan du lieu
        ProductSL10 product=list.get(position);
        if(product!=null){
            Picasso.get().load(product.getSearch_image()).into(holder.imageView);
            holder.styleidTv.setText(product.getStyleid());
            holder.addInfoTv.setText(product.getProduct_additional_info());
        }
        //event
        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ProductSL10 p=list.get(position);
                Intent intent=new Intent(mContext,Slot11DetailActivity.class);
                intent.putExtra("PRD",p);
                mContext.startActivity(intent);
            }
        });
        return convertView;
    }
    static class ViewHolderSL10 {
        ImageView imageView;
        TextView styleidTv;
        TextView addInfoTv;

    }
}
