package com.hnq40.myapplication10.slot10;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.hnq40.myapplication10.R;

import java.util.List;

public class CartAdapterSL11 extends ArrayAdapter<ProductSL10> {
    private Context mContext;

    public CartAdapterSL11(Context context,List<ProductSL10> products) {
        super(context, 0, products);
        this.mContext=context;
    }

    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItem=convertView;
        if(listItem==null){
            listItem= LayoutInflater.from(mContext).inflate(R.layout.slot11_cart_items,parent,false);
        }
        //lay ve prd hien tai
        ProductSL10 currentP=getItem(position);
        //hien thi thong tin san pham trong danh sach gio hang
        TextView tvPrdId=listItem.findViewById(R.id.slot11_cartItem_styleid);
        tvPrdId.setText(currentP.getStyleid());
        TextView tvPrdQuantity=listItem.findViewById(R.id.slot11_cartItem_quantity);
        tvPrdQuantity.setText("Quantity: "+1);
        return listItem;
    }

}
