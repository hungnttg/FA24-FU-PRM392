package com.hnq40.myapplication10.slot10;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.hnq40.myapplication10.R;
import com.squareup.picasso.Picasso;

public class Slot11DetailActivity extends AppCompatActivity {
    private CartManager cartManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot11_detail);
        //anh xa thanh phan
        ImageView img=findViewById(R.id.slot11DetailImg);
        TextView tvId=findViewById(R.id.slot11DetailstyleidTv);
        TextView tvInfo=findViewById(R.id.slot11DetailaddInfoTv);
        Button btnAddToCart=findViewById(R.id.slot11DetailBtnAddToCart);
        //khoi tao gio hang
        cartManager=CartManager.getInstance();
        //nhan du lieu tu intent
        Intent intent=getIntent();
        //lay ve product
        ProductSL10 p=intent.getParcelableExtra("PRD");
        //
        if(p!=null){
            Picasso.get().load(p.getSearch_image()).into(img);
            tvId.setText("StyleID: "+p.getStyleid());
            tvInfo.setText("More Info: "+p.getProduct_additional_info());
        }
        //xu ly su kien add to cart
        btnAddToCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addToCartClicked();
            }
        });
    }
    private void addToCartClicked(){
        Intent intent=getIntent();
        ProductSL10 p=intent.getParcelableExtra("PRD");
        if(p!=null){
            //them san pham vao gio hang
            cartManager.addProductToCart(p);
            //mo CartActivity
            Intent intent1=new Intent(this,Slot11CartActivity.class);
            startActivity(intent1);
        }
    }
}