package com.hnq40.myapplication10.slot8;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.hnq40.myapplication10.R;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Slot8MainActivity extends AppCompatActivity {
    Context context=this;
    EditText txtU,txtP;
    Button btnLogin,btnCancel,btnRead,btnSave;
    TextView tvResult;
    CheckBox chkSave;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot8_main);
        txtP=findViewById(R.id.slot81TxtP);
        txtU=findViewById(R.id.slot81TxtU);
        btnLogin=findViewById(R.id.slot81BtnLogin);
        btnCancel=findViewById(R.id.slot81BtnCancel);
        chkSave=findViewById(R.id.slot81Chk);
        tvResult=findViewById(R.id.slot81TvResult);
        btnRead=findViewById(R.id.slot81BtnRead);
        btnSave=findViewById(R.id.slot81BtnSave);
        requestPermission();
        restoreUP();
        btnLogin.setOnClickListener(v->{
            login();
        });
        btnCancel.setOnClickListener(v->{

        });
        btnSave.setOnClickListener(v->{
            String kq=saveData(txtU.getText().toString(),context);
            tvResult.setText(kq);
        });
        btnRead.setOnClickListener(v->{
            String kq=readData(context);
            tvResult.setText(kq);
        });

    }
    String strU="";
    String strP="";
    public void login(){
        //lay du lieu nguoi dung nhap
        strU=txtU.getText().toString();
        strP=txtP.getText().toString();
        //validate
        if(strU.isEmpty()||strP.isEmpty()){
            Toast.makeText(context,"U,P is not empty",Toast.LENGTH_SHORT).show();
            return;
        }
        if(strU.equalsIgnoreCase("admin")&&strP.equalsIgnoreCase("admin")){
            saveUPToPreference(strU,strP,chkSave.isChecked());
            Toast.makeText(context,"Login successfully",Toast.LENGTH_SHORT).show();
        }
    }

    private void saveUPToPreference(String u, String p, boolean status) {
        //b1- create file for saving
        SharedPreferences sharedPreferences=getSharedPreferences("H",MODE_PRIVATE);
        //b2- Enable editor mode
        SharedPreferences.Editor editor=sharedPreferences.edit();
        if(!status){//if exist password
            editor.clear();//clear old password
        }
        else {
            //save new data
            editor.putString("USERNAME",u);
            editor.putString("PASSWORD",p);
            editor.putBoolean("REMEMBER",status);
        }
        //commit data to file
        editor.commit();
    }
    private List<Object> restoreUP(){
        List<Object> list=new ArrayList<>();
        //b1- open file
        SharedPreferences sharedPreferences=getSharedPreferences("H",MODE_PRIVATE);
        //b2- check request
        boolean check=sharedPreferences.getBoolean("REMEMBER",false);
        if(check){
            String u=sharedPreferences.getString("USERNAME","");
            txtU.setText(u);
            String p=sharedPreferences.getString("PASSWORD","");
            txtP.setText(p);
            list.add(u);
            list.add(p);
            list.add(check);
        }
        chkSave.setChecked(check);
        return list;
    }
    //
    private boolean requestPermission(){
        if(Build.VERSION.SDK_INT>=23){
            if(checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
            == PackageManager.PERMISSION_GRANTED
            && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            == PackageManager.PERMISSION_GRANTED
            && checkSelfPermission(Manifest.permission.MANAGE_EXTERNAL_STORAGE)
            == PackageManager.PERMISSION_GRANTED){
                return true;
            }
            else {
                ActivityCompat.requestPermissions(Slot8MainActivity.this, new String[]{
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.MANAGE_EXTERNAL_STORAGE
                },1);
                return false;
            }
        }
        else {
            return true;
        }
    }
    private String saveData(String data,Context context){
        //b1- get path
        String path="";
        ContextWrapper cw= new ContextWrapper(context);
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.GINGERBREAD_MR1){
            path=cw.getExternalFilesDir(Environment.DIRECTORY_DCIM)+"/data1.txt";
        }
        else {
            path=Environment.getExternalStorageDirectory().getAbsolutePath()+"/data.txt";
        }
        //b2- create a stream for saving
        try {
            OutputStreamWriter o=new OutputStreamWriter(new FileOutputStream(path));
            //b3- write data
            o.write(data);
            o.close();
            return "Save data successfully";
        } catch (FileNotFoundException e) {
            //throw new RuntimeException(e);
            return e.getMessage();
        } catch (IOException e) {
            //throw new RuntimeException(e);
            return e.getMessage();
        }
    }
    private String readData(Context context){
        String result="";
        String path="";
        ContextWrapper cw=new ContextWrapper(context);
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.GINGERBREAD_MR1){
            path=cw.getExternalFilesDir(Environment.DIRECTORY_DCIM)+"/data1.txt";
        }
        else {
            path=Environment.getExternalStorageDirectory().getAbsolutePath()+"/data.txt";
        }
        try {
            Scanner s=new Scanner(new File(path));
            while (s.hasNext()){
                result=s.nextLine()+"\n";
            }
            s.close();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        return result;
    }
}