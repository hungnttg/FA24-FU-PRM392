<!doctype html>
<?php
  session_start();//bat dau 1 phien lam viecj
  require_once('SP.php');//import thu vien
  global $result;//ket qua
  $editId="";
  if(isset($_POST['btnEdit'])){//neu nguoi dung click vao button edit thi se lam gi
    $editId = $_POST['editId'];
  }
?>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>
      <div class="jumbotron">
        <h1 class="display-3">Quan tri san pham</h1>
        <p class="lead">more detail...</p>
        <hr class="my-2">
      </div>
      <div class="card-columns">
        <div class="card">
            <img class="card-img-top" src="holder.js/100x180/" alt="">
            <div class="card-body">
                <h4 class="card-title">Them san pham</h4>
                <form action="" method="post">
                    <div class="form-group">
                      <label for="">ID</label>
                      <input type="text" value="<?php echo $editId; ?>"
                        class="form-control" name="txtId" id="txtId" aria-describedby="helpId" placeholder="Nhap id">
                      <small id="helpId" class="form-text text-muted">Help text</small>
                    </div>
                    <div class="form-group">
                        <label for="">Name</label>
                        <input type="text"
                          class="form-control" name="txtName" id="txtName" aria-describedby="helpId" placeholder="Nhap name">
                        <small id="helpId" class="form-text text-muted">Help text</small>
                    </div>
                    <div class="form-group">
                        <label for="">Price</label>
                        <input type="text"
                          class="form-control" name="txtPrice" id="txtPrice" aria-describedby="helpId" placeholder="Nhap price">
                        <small id="helpId" class="form-text text-muted">Help text</small>
                      </div>
                      <div class="form-group">
                        <label for="">Des</label>
                        <input type="text"
                          class="form-control" name="txtDes" id="txtDes" aria-describedby="helpId" placeholder="Nhap Des">
                        <small id="helpId" class="form-text text-muted">Help text</small>
                      </div>
                      <button type="submit" name="btnThem" class="btn btn-primary">Them</button>
                      <button type="submit" name="btnUpdate" class="btn btn-primary">Update</button>
                      <button type="submit" name="btnHienThi" class="btn btn-primary">Hien Thi</button>
                </form>
            </div>
        </div>
        <div class="card">
            <img class="card-img-top" src="holder.js/100x180/" alt="">
            <div class="card-body">
                <h4 class="card-title">Danh sach san pham</h4>
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Price</th>
                            <th>Des</th>
                        </tr>
                    </thead>
                    <tbody>
                      <?php
                        if(isset($_POST['btnHienThi'])){//neu button hien thi duoc click
                            $result=displaySP();//doc du lieu tu DB
                            while($row=$result->fetch_assoc())//doc tung dong
                            {
                              echo '<tr>';
                              echo '<td scope="row"></td>';
                              echo '<td>'.$row['name'].'</td>';
                              echo '<td>'.$row['price'].'</td>';
                              echo '<td>'.$row['description'].'</td>';
                              echo '<td>
                                    <form action="" method="post"> 
                                        <input type="hidden" name="editId" value="'.$row['id'].'" >
                                        <button type="submit" name="btnEdit" class="btn btn-primary">Edit</button>
                                      </form>
                                    </td>';
                              echo '<td>
                                  <form action="" method="post"> 
                                      <input type="hidden" name="deleteId" value="'.$row['id'].'" >
                                      <button type="submit" name="btnDelete" class="btn btn-primary">Delete</button>
                                    </form>
                                  </td>';
                            }
                        }
                      ?>
    
                    </tbody>
                </table>
            </div>
        </div>
      </div>
      <?php
        if(isset($_POST['btnThem'])){//neu button them duoc click
            $id=$_POST['txtId'];
            $name=$_POST['txtName'];
            $price=$_POST['txtPrice'];
            $description = $_POST['txtDes'];
            $i=addSP($id,$name,$price,$description);
            if($i<0){
              echo "Them that bai";
            }
            else {
              echo "Them thanh cong";
            }
        }
        if(isset($_POST['btnDelete'])){//neu button delete duoc click
          $id=$_POST['deleteId'];
          $i=deleteSP($id);
          if($i<0){
            echo "Xoa that bai";
          }
          else {
            echo "Xoa thanh cong";
          }
        }
        if(isset($_POST['btnEdit'])){//neu button delete duoc click
          $id=$_POST['editId'];
          echo "Sua voi ma san pham: $id";
        }
        if(isset($_POST['btnUpdate'])){//neu button update duoc click
            $id=$_POST['txtId'];
            $name=$_POST['txtName'];
            $price=$_POST['txtPrice'];
            $description = $_POST['txtDes'];
          $i=updateSP($id,$name,$price,$description);
          if($i<0){
            echo "update that bai";
          }
          else {
            echo "update thanh cong";
          }
        }
      ?>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>