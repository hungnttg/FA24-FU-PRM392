<?php
    function ketNoiDB(){
        return new mysqli('localhost','root','','a6');
    }
    function addSP($id,$name,$price,$description){
        $con=ketNoiDB();
        $i=$con->query('INSERT INTO products VALUES ("'.$id.'","'.$name.'","'.$price.'","'.$description.'")');
        return $i;
    }
    function displaySP(){
        $con=ketNoiDB();
        $result = $con->query("SELECT * from products");
        return $result;
    }
    function deleteSP($id){
        $con=ketNoiDB();
        $i=$con->query('DELETE FROM products WHERE id="'.$id.'"');
        return $i;
    }
    function updateSP($id,$name,$price,$description){
        $con=ketNoiDB();
        $i=$con->query('UPDATE products SET name="'.$name.'", price="'.$price.'", description="'.$description.'" where id="'.$id.'"');
    }
?>