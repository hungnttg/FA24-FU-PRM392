package com.hnq40.myapplication10.slot9;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.annotation.SuppressLint;
import android.os.Bundle;

import com.google.android.material.navigation.NavigationView;
import com.hnq40.myapplication10.R;
@SuppressLint("MissingInflatedId")
public class Slot92MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot92_main);
        DrawerLayout drawerLayout=findViewById(R.id.slot92Drawlayout);
        NavigationView navigationView=findViewById(R.id.slot92NavigationView);
    }
}