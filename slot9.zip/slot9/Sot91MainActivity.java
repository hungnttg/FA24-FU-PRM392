package com.hnq40.myapplication10.slot9;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.TextView;

import com.hnq40.myapplication10.R;

public class Sot91MainActivity extends AppCompatActivity {
    TextView tv1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sot91_main);
        tv1=findViewById(R.id.slot91Tv1);
        //copy font to android system
        Typeface typeface=Typeface.createFromAsset(getAssets(),"Blazed.ttf");
        //use for textview
        tv1.setTypeface(typeface);
    }
}