package com.hnq40.myapplication10.slot4;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ListView;

import com.hnq40.myapplication10.R;

import java.util.ArrayList;
import java.util.List;

public class Slot41MainActivity extends AppCompatActivity {
    ListView listView;
    private Slot41Adapter adapter;
    private List<Student1> list=new ArrayList<>();
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot41_main);
        listView=findViewById(R.id.slot41Lv);
        list.add(new Student1("Nguyen Van A","18",R.drawable.android));
        list.add(new Student1("Tran Van B","19",R.drawable.apple));
        list.add(new Student1("Vu Van C","17",R.drawable.blogger));
        list.add(new Student1("Nguyen Thi E","16",R.drawable.chrome));
        list.add(new Student1("Tran Thi F","20",R.drawable.facebook));
        list.add(new Student1("Nguyen Van G","18",R.drawable.android));
        list.add(new Student1("Nguyen Van H","18",R.drawable.apple));
        list.add(new Student1("Hoang Van K","17",R.drawable.dell));
        adapter=new Slot41Adapter(this,list);//create an adapter
        listView.setAdapter(adapter);//attach adapter to list view
    }
}