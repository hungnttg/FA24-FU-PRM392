package com.hnq40.myapplication10.slot4;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.hnq40.myapplication10.R;

import java.util.List;

public class Slot41Adapter extends BaseAdapter {
    private Context context;
    private List<Student1> list;
    //ham khoi tao
    public Slot41Adapter(Context context, List<Student1> list) {
        this.context = context;
        this.list = list;
    }
    //tong so item
    @Override
    public int getCount() {
        return list.size();
    }
    //lay ve item hien tai
    @Override
    public Object getItem(int position) {
        return list.get(position);
    }
    //lay ve item id
    @Override
    public long getItemId(int position) {
        return position;
    }
    //create a blank view and refer to view holder
    //set data for view
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //1.create view
        Slot41ViewHolder holder;
        if(convertView==null)//not exist view, create a new view
        {
          //create a blank view
          convertView= LayoutInflater.from(context).inflate(R.layout.slot41_item_view,parent,false);
            //refer to view holder
            holder=new Slot41ViewHolder();
            holder.img_hinh=convertView.findViewById(R.id.slot41_item_hinh);
            holder.tvTen=convertView.findViewById(R.id.slot41_item_ten);
            holder.tvTuoi=convertView.findViewById(R.id.slot41_item_tuoi);
            //create a template for late
            convertView.setTag(holder);
        }
        else {//exist view= > get old view
            holder=(Slot41ViewHolder) convertView.getTag();
        }
        //2. setdata

        Student1 student1=list.get(position);//get a object
        holder.img_hinh.setImageResource(student1.getHinh());
        holder.tvTen.setText(student1.getTen());
        holder.tvTuoi.setText(student1.getTuoi());
        return convertView;
    }
    //create a class for refer to components of item view
    static class Slot41ViewHolder {
        ImageView img_hinh;
        TextView tvTen,tvTuoi;
    }
}
