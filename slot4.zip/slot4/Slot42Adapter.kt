package com.hnq40.myapplication10.slot4

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import com.hnq40.myapplication10.R

class Slot42Adapter(val ls: ArrayList<Student2>, val context: Context): BaseAdapter() {
    override fun getCount(): Int {
        return ls.size
    }

    override fun getItem(position: Int): Any {
        return ls[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View? {
        var holder: Demo42ViewHolder
        var convertView=convertView
        if(convertView==null){
            holder= Demo42ViewHolder()
            //tao layout trang
            convertView=LayoutInflater.from(context).inflate(R.layout.slot41_item_view,null)
            //anh xa tung thanh phan
            holder.img_hinh=convertView.findViewById(R.id.slot41_item_hinh)
            holder.tv_ten=convertView.findViewById(R.id.slot41_item_ten)
            holder.tv_tuoi=convertView.findViewById(R.id.slot41_item_tuoi)
            //tao template de lan sau su dung
            convertView.tag=holder
        }
        else{//neu da ton tai view -> lay ve view cu
            holder=convertView.tag as Demo42ViewHolder
        }
        //gan du lieu cho view
        holder.img_hinh!!.setImageResource(ls[position].hinh)
        holder.tv_ten!!.text=ls[position].ten
        holder.tv_tuoi!!.text=ls[position].tuoi
        return convertView
    }
    internal class Demo42ViewHolder {
        var img_hinh: ImageView? = null
        var tv_ten: TextView? = null
        var tv_tuoi: TextView? =null
    }

}