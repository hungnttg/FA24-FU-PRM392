package com.hnq40.myapplication10.slot4

class Student2 {
    var ten: String? = null
    var tuoi: String? = null
    var hinh: Int = 0

    constructor(ten: String?, tuoi: String?, hinh: Int) {
        this.ten = ten
        this.tuoi = tuoi
        this.hinh = hinh
    }
}