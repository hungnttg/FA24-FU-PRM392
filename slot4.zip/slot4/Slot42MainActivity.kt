package com.hnq40.myapplication10.slot4

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView
import com.hnq40.myapplication10.R

class Slot42MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_slot41_main)
        var lv = findViewById<ListView>(R.id.slot41Lv)
        var ls=ArrayList<Student2>()
        ls.add(Student2("AAA","11",R.drawable.android))
        ls.add(Student2("BBB","10",R.drawable.apple))
        ls.add(Student2("DDD","13",R.drawable.blogger))
        ls.add(Student2("CCC","15",R.drawable.facebook))
        var adapter=Slot42Adapter(ls,this)
        lv!!.adapter=adapter
    }
}