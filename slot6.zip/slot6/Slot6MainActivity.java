package com.hnq40.myapplication10.slot6;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.hnq40.myapplication10.R;

import java.util.ArrayList;
import java.util.List;

public class Slot6MainActivity extends AppCompatActivity {
    EditText txt1,txt2,txt3;
    Button btnI,btnU,btnD,btnS;
    ListView lv;
    ArrayAdapter<String> adapter;
    List<String> ls=new ArrayList<>();
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot6_main);
        txt1=findViewById(R.id.sl6Txt1);
        txt2=findViewById(R.id.sl6Txt2);
        txt3=findViewById(R.id.sl6Txt3);
        btnI=findViewById(R.id.sl6Insert);
        btnU=findViewById(R.id.sl6Update);
        btnD=findViewById(R.id.sl6Delete);
        btnS=findViewById(R.id.sl6Select);
        lv=findViewById(R.id.sl6Lv);
        Slot6DAO dao=new Slot6DAO(this);
        btnI.setOnClickListener(v->{
            SanPhamSL6 p=new SanPhamSL6();
            p.setMasp(txt1.getText().toString());
            p.setTensp(txt2.getText().toString());
            p.setSoluongSP(Integer.parseInt(txt3.getText().toString()));
            int kq=dao.insertSanPham(p);
            if(kq<=0){
                Toast.makeText(getApplicationContext(),"That bai",Toast.LENGTH_SHORT).show();
            }
            else
            {
                Toast.makeText(getApplicationContext(),"Thanh cong",Toast.LENGTH_SHORT).show();
            }
        });
        btnD.setOnClickListener(v->{
            int kq=dao.deleteSanPham(txt1.getText().toString());
            if(kq<=0){
                Toast.makeText(getApplicationContext(),"That bai",Toast.LENGTH_SHORT).show();
            }
            else
            {
                Toast.makeText(getApplicationContext(),"Thanh cong",Toast.LENGTH_SHORT).show();
            }
        });
        btnU.setOnClickListener(v->{
            SanPhamSL6 p=new SanPhamSL6();
            p.setMasp(txt1.getText().toString());
            p.setTensp(txt2.getText().toString());
            p.setSoluongSP(Integer.parseInt(txt3.getText().toString()));
            int kq=dao.updateSanPham(p);
            if(kq<=0){
                Toast.makeText(getApplicationContext(),"That bai",Toast.LENGTH_SHORT).show();
            }
            else
            {
                Toast.makeText(getApplicationContext(),"Thanh cong",Toast.LENGTH_SHORT).show();
            }
        });
        btnS.setOnClickListener(v->{
            ls.clear();//xoa danh sach cu
            ls=dao.getAllSanPhamToString();
            adapter=new ArrayAdapter<>(Slot6MainActivity.this,
                    android.R.layout.simple_list_item_1,ls);
            lv.setAdapter(adapter);
        });
    }
}