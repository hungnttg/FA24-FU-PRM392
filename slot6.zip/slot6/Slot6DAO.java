package com.hnq40.myapplication10.slot6;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class Slot6DAO {
    private SQLiteDatabase db;
    private Slot6SQLiteHelper dbhelper;
    private Context context;

    public Slot6DAO(Context context) {
        this.context = context;
        dbhelper=new Slot6SQLiteHelper(context);
        db=dbhelper.getWritableDatabase();
    }
    //insert
    public int insertSanPham(SanPhamSL6 p){
        ContentValues values=new ContentValues();
        values.put("masp",p.getMasp());
        values.put("tensp",p.getTensp());
        values.put("soluongSP",String.valueOf(p.getSoluongSP()));
        if(db.insert("sanpham",null,values)<0){
            return -1;
        }
        return 1;
    }
    //delete
    public int deleteSanPham(String masp){
        if(db.delete("sanpham","masp=?",new String[]{masp})<=0){
            return -1;
        }
        return 1;
    }
    //update
    public int updateSanPham(SanPhamSL6 p){
        ContentValues values=new ContentValues();
        values.put("masp",p.getMasp());
        values.put("tensp",p.getTensp());
        values.put("soluongSP",String.valueOf(p.getSoluongSP()));
        if(db.update("sanpham",values,"masp=?",new String[]{p.getMasp()}) <=0){
            return -1;
        }
        return 1;
    }
    //select all
    public List<String> getAllSanPhamToString(){
        List<String> list=new ArrayList<>();
        Cursor c=db.query("sanpham",null,null,
                null,null,null,null);
        c.moveToFirst();
        while (c.isAfterLast()==false){
            SanPhamSL6 s=new SanPhamSL6();
            s.setMasp(c.getString(0));
            s.setTensp(c.getString(1));
            s.setSoluongSP(c.getInt(2));
            String chuoi=s.getMasp()+" - "+s.getTensp()+" - "+s.getSoluongSP();
            list.add(chuoi);
            c.moveToNext();
        }
        c.close();
        return list;
    }
}
