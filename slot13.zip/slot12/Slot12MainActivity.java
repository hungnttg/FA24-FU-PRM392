package com.hnq40.myapplication10.slot12;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.hnq40.myapplication10.R;
import com.hnq40.myapplication10.slot12.insert.InterfacePrdInsert;
import com.hnq40.myapplication10.slot12.insert.Prd;
import com.hnq40.myapplication10.slot12.insert.SvrResponsePrd;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Slot12MainActivity extends AppCompatActivity {
    EditText txt1,txt2,txt3,txt4;
    Button btnI,btnU,btnD,btnS;
    TextView tvKQ;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot12_main);
        txt1=findViewById(R.id.slot12TxtId);
        txt2=findViewById(R.id.slot12TxtName);
        txt3=findViewById(R.id.slot12TxtPrice);
        txt4=findViewById(R.id.slot12TxtDes);
        btnI=findViewById(R.id.slot12BtnThem);
        tvKQ=findViewById(R.id.slot13TvKQ);
        btnI.setOnClickListener(v->{
            Prd p=new Prd();
            p.setId(txt1.getText().toString());
            p.setName(txt2.getText().toString());
            p.setPrice(txt3.getText().toString());
            p.setDescription(txt4.getText().toString());
            insertData(p);
        });
        btnS = findViewById(R.id.slot12BtnHT);
        btnS.setOnClickListener(v->{
            selectData(tvKQ);
        });
    }
    String stringKQ="";
    List<Prd> ls;
    private void selectData(TextView tv){
        stringKQ="";
        //1. Tao doi tuong retrofit
        Retrofit retrofit=new Retrofit.Builder()
                .baseUrl("http://10.22.10.72/0prm/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        //2. goi ham select trong interface
        //2.1. tao doi tuong
        InterfacePrdInsert interfacePrdInsert=retrofit.create(InterfacePrdInsert.class);
        //2.2 chuan bi ham
        Call<SvrResponsePrd> call=interfacePrdInsert.getProd();
        //2.3. thuc thi ham
        call.enqueue(new Callback<SvrResponsePrd>() {
            //thanh cong
            @Override
            public void onResponse(Call<SvrResponsePrd> call, Response<SvrResponsePrd> response) {
                SvrResponsePrd svrResponsePrd=response.body();//lay du lieu do server tra ve
                //chuyen ke qua sang dang list
                ls=new ArrayList<>(Arrays.asList(svrResponsePrd.getProducts()));
                //dua vao vong lap for
                for (Prd p: ls){
                    stringKQ+="Name: "+p.getName()+"; Price: "+p.getPrice()+"; Des: "+p.getDescription()+"\n";
                }
                tv.setText(stringKQ);
            }
            //that bai
            @Override
            public void onFailure(Call<SvrResponsePrd> call, Throwable throwable) {
                tv.setText(throwable.getMessage());
            }
        });
    }

    private void insertData(Prd p){
        //b1. tao doi tuong retrofit
        Retrofit retrofit=new Retrofit.Builder()
                .baseUrl("http://10.22.10.72/0prm/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        //b2. tao doi tuong
        InterfacePrdInsert interfacePrdInsert=retrofit.create(InterfacePrdInsert.class);
        //b3. chuan bi ham
        Call<SvrResponsePrd> call=interfacePrdInsert.insertPrd(p.getId(),p.getName(),
                p.getPrice(),p.getDescription());
        //b4. thuc thi ham
        call.enqueue(new Callback<SvrResponsePrd>() {
            //thanh cong
            @Override
            public void onResponse(Call<SvrResponsePrd> call, Response<SvrResponsePrd> response) {
                SvrResponsePrd svrResponsePrd=response.body();//lay ve ket qua tu server
                //hien thi len man hinh cho nguoi dung biet
                Toast.makeText(getApplicationContext(),svrResponsePrd.getMessage(),Toast.LENGTH_SHORT).show();
            }
            //that bai
            @Override
            public void onFailure(Call<SvrResponsePrd> call, Throwable throwable) {
                //hien thi messagebox
                Toast.makeText(getApplicationContext(),throwable.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });
    }
}