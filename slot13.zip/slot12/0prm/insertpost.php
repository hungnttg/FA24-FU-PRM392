<?php
$response = array();
$host="localhost";$u="root";$p="";$db="a6";//khai bao thong tin csdl
$conn=new mysqli($host,$u,$p,$db);//tao ket noi
//truyen tham so
if(isset($_POST['id']) && isset($_POST['name']) && isset($_POST['price'])&& isset($_POST['description'])){
    //lay gia tri cua cac tham so
    $id=$_POST['id'];
    $name=$_POST['name'];
    $price=$_POST['price'];
    $description=$_POST['description'];
    $sql="insert into products values ('$id','$name','$price','$description')";
    if($conn->query($sql)===TRUE){
        $response['success']=1;
        $response['message']="Insert thanh cong";
        echo json_encode($response);
    }
    else {
        $response['success']=1;
        $response['message']=$conn->error;
        echo json_encode($response);
    }
}
$conn->close();
