package com.hnq40.myapplication10.slot12.insert;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface InterfacePrdInsert {
    @FormUrlEncoded
    @POST("insertpost.php")
    Call<SvrResponsePrd> insertPrd(
            @Field("id") String id,
            @Field("name") String name,
            @Field("price") String price,
            @Field("description") String description
    );
    @GET("select.php")
    Call<SvrResponsePrd> getProd();

}
