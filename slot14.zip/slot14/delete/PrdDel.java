package com.hnq40.myapplication10.slot14.delete;

public class PrdDel {
    private String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
