package com.hnq40.myapplication10.slot14.delete;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface InterfaceDel {
    @FormUrlEncoded
    @POST("delete.php")
    Call<SvrResDel> deleteExe(@Field("id") String id);
}
