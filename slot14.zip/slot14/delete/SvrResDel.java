package com.hnq40.myapplication10.slot14.delete;

public class SvrResDel {
    private PrdDel products;
    private String message;

    public PrdDel getProducts() {
        return products;
    }

    public void setProducts(PrdDel products) {
        this.products = products;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
