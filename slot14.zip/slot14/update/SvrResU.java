package com.hnq40.myapplication10.slot14.update;

public class SvrResU {
    private PrdU products;
    private String message;

    public PrdU getProducts() {
        return products;
    }

    public void setProducts(PrdU products) {
        this.products = products;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
