package com.hnq40.myapplication10.slot14;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.hnq40.myapplication10.R;
import com.hnq40.myapplication10.slot12.insert.SvrResponsePrd;
import com.hnq40.myapplication10.slot14.delete.InterfaceDel;
import com.hnq40.myapplication10.slot14.delete.SvrResDel;
import com.hnq40.myapplication10.slot14.update.InterfaceU;
import com.hnq40.myapplication10.slot14.update.PrdU;
import com.hnq40.myapplication10.slot14.update.SvrResU;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Slot14MainActivity extends AppCompatActivity {
    TextView tv;
    EditText txtId,txtName,txtPrice,txtDes;
    Button btnSua,btnXoa;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot12_main);
        tv=findViewById(R.id.slot13TvKQ);
        txtId=findViewById(R.id.slot12TxtId);
        txtName=findViewById(R.id.slot12TxtName);
        txtPrice=findViewById(R.id.slot12TxtPrice);
        txtDes=findViewById(R.id.slot12TxtDes);
        btnSua=findViewById(R.id.slot12BtnSua);
        btnXoa=findViewById(R.id.slot12BtnXoa);
        btnXoa.setOnClickListener(v->{
            DeleteFn(tv,txtId.getText().toString().trim());
        });
        btnSua.setOnClickListener(v->{
            PrdU p=new PrdU();
            p.setId(txtId.getText().toString().trim());
            p.setName(txtName.getText().toString().trim());
            p.setPrice(txtPrice.getText().toString().trim());
            p.setDescription(txtDes.getText().toString().trim());
            UpdateFn(tv,p);
        });
    }
    private void UpdateFn(TextView tv, PrdU p){
        //1.Tao doi tuong retrofit
        Retrofit retrofit=new Retrofit.Builder()
                .baseUrl("http://10.22.10.72/0prm/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        //2. goi interface
        InterfaceU interfaceU=retrofit.create(InterfaceU.class);
        Call<SvrResU> call=interfaceU.updateFn(p.getId(),p.getName(),p.getPrice(),p.getDescription());
        //3. thuc thi ham
        call.enqueue(new Callback<SvrResU>() {
            @Override
            public void onResponse(Call<SvrResU> call, Response<SvrResU> response) {
                SvrResU res=response.body();
                tv.setText(res.getMessage());
            }

            @Override
            public void onFailure(Call<SvrResU> call, Throwable throwable) {
                tv.setText(throwable.getMessage());
            }
        });
    }
    private void DeleteFn(TextView tv,String id){
        //1. Tao doi tuong
        Retrofit retrofit=new Retrofit.Builder()
                .baseUrl("http://10.22.10.72/0prm/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        //2. goi interface
        InterfaceDel interfaceDel=retrofit.create(InterfaceDel.class);
        Call<SvrResDel> call=interfaceDel.deleteExe(id);
        //3.thuc thi delete
        call.enqueue(new Callback<SvrResDel>() {
            @Override
            public void onResponse(Call<SvrResDel> call, Response<SvrResDel> response) {
                SvrResDel res=response.body();
                tv.setText(res.getMessage());
            }

            @Override
            public void onFailure(Call<SvrResDel> call, Throwable throwable) {
                tv.setText(throwable.getMessage());
            }
        });
    }
}